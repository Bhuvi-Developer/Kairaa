import React from 'react';
import LandingPage from '../components/LandingPage';

const HomePage = () => {
  return <LandingPage />;
  
};

export default HomePage;
